import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
export const referenceImage = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: referenceImage.url(args, options),
    method: 'get',
})

referenceImage.definition = {
    methods: ["get","head"],
    url: '/payments/{payment}/reference-image',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
referenceImage.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return referenceImage.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
referenceImage.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: referenceImage.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
referenceImage.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: referenceImage.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
    const referenceImageForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: referenceImage.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
        referenceImageForm.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: referenceImage.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::referenceImage
 * @see app/Http/Controllers/PaymentController.php:173
 * @route '/payments/{payment}/reference-image'
 */
        referenceImageForm.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: referenceImage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    referenceImage.form = referenceImageForm
const payment = {
    referenceImage: Object.assign(referenceImage, referenceImage),
}

export default payment