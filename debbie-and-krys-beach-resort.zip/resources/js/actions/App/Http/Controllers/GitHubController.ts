import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
export const getUpdates = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUpdates.url(options),
    method: 'get',
})

getUpdates.definition = {
    methods: ["get","head"],
    url: '/api/github-updates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
getUpdates.url = (options?: RouteQueryOptions) => {
    return getUpdates.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
getUpdates.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getUpdates.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
getUpdates.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getUpdates.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
    const getUpdatesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: getUpdates.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
        getUpdatesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUpdates.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\GitHubController::getUpdates
 * @see app/Http/Controllers/GitHubController.php:12
 * @route '/api/github-updates'
 */
        getUpdatesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: getUpdates.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    getUpdates.form = getUpdatesForm
const GitHubController = { getUpdates }

export default GitHubController