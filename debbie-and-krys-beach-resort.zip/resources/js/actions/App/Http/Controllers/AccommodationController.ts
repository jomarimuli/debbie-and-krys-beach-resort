import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/accommodations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AccommodationController::index
 * @see app/Http/Controllers/AccommodationController.php:26
 * @route '/accommodations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/accommodations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AccommodationController::create
 * @see app/Http/Controllers/AccommodationController.php:38
 * @route '/accommodations/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AccommodationController::store
 * @see app/Http/Controllers/AccommodationController.php:43
 * @route '/accommodations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/accommodations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AccommodationController::store
 * @see app/Http/Controllers/AccommodationController.php:43
 * @route '/accommodations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::store
 * @see app/Http/Controllers/AccommodationController.php:43
 * @route '/accommodations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AccommodationController::store
 * @see app/Http/Controllers/AccommodationController.php:43
 * @route '/accommodations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::store
 * @see app/Http/Controllers/AccommodationController.php:43
 * @route '/accommodations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
export const show = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/accommodations/{accommodation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
show.url = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { accommodation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { accommodation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    accommodation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        accommodation: typeof args.accommodation === 'object'
                ? args.accommodation.id
                : args.accommodation,
                }

    return show.definition.url
            .replace('{accommodation}', parsedArgs.accommodation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
show.get = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
show.head = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
    const showForm = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
        showForm.get = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AccommodationController::show
 * @see app/Http/Controllers/AccommodationController.php:67
 * @route '/accommodations/{accommodation}'
 */
        showForm.head = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
export const edit = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/accommodations/{accommodation}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
edit.url = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { accommodation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { accommodation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    accommodation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        accommodation: typeof args.accommodation === 'object'
                ? args.accommodation.id
                : args.accommodation,
                }

    return edit.definition.url
            .replace('{accommodation}', parsedArgs.accommodation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
edit.get = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
edit.head = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
    const editForm = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
        editForm.get = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AccommodationController::edit
 * @see app/Http/Controllers/AccommodationController.php:76
 * @route '/accommodations/{accommodation}/edit'
 */
        editForm.head = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
export const update = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/accommodations/{accommodation}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
update.url = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { accommodation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { accommodation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    accommodation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        accommodation: typeof args.accommodation === 'object'
                ? args.accommodation.id
                : args.accommodation,
                }

    return update.definition.url
            .replace('{accommodation}', parsedArgs.accommodation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
update.put = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
update.patch = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
    const updateForm = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
        updateForm.put = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AccommodationController::update
 * @see app/Http/Controllers/AccommodationController.php:83
 * @route '/accommodations/{accommodation}'
 */
        updateForm.patch = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AccommodationController::destroy
 * @see app/Http/Controllers/AccommodationController.php:118
 * @route '/accommodations/{accommodation}'
 */
export const destroy = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/accommodations/{accommodation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AccommodationController::destroy
 * @see app/Http/Controllers/AccommodationController.php:118
 * @route '/accommodations/{accommodation}'
 */
destroy.url = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { accommodation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { accommodation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    accommodation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        accommodation: typeof args.accommodation === 'object'
                ? args.accommodation.id
                : args.accommodation,
                }

    return destroy.definition.url
            .replace('{accommodation}', parsedArgs.accommodation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AccommodationController::destroy
 * @see app/Http/Controllers/AccommodationController.php:118
 * @route '/accommodations/{accommodation}'
 */
destroy.delete = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AccommodationController::destroy
 * @see app/Http/Controllers/AccommodationController.php:118
 * @route '/accommodations/{accommodation}'
 */
    const destroyForm = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AccommodationController::destroy
 * @see app/Http/Controllers/AccommodationController.php:118
 * @route '/accommodations/{accommodation}'
 */
        destroyForm.delete = (args: { accommodation: number | { id: number } } | [accommodation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AccommodationController = { index, create, store, show, edit, update, destroy }

export default AccommodationController