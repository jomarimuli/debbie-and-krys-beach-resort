import WelcomeController from './WelcomeController'
import Auth from './Auth'
import GitHubController from './GitHubController'
import UserController from './UserController'
import RoleController from './RoleController'
import AccommodationController from './AccommodationController'
import AccommodationRateController from './AccommodationRateController'
import BookingController from './BookingController'
import PaymentController from './PaymentController'
import FeedbackController from './FeedbackController'
import GalleryController from './GalleryController'
import AnnouncementController from './AnnouncementController'
import Settings from './Settings'
const Controllers = {
    WelcomeController: Object.assign(WelcomeController, WelcomeController),
Auth: Object.assign(Auth, Auth),
GitHubController: Object.assign(GitHubController, GitHubController),
UserController: Object.assign(UserController, UserController),
RoleController: Object.assign(RoleController, RoleController),
AccommodationController: Object.assign(AccommodationController, AccommodationController),
AccommodationRateController: Object.assign(AccommodationRateController, AccommodationRateController),
BookingController: Object.assign(BookingController, BookingController),
PaymentController: Object.assign(PaymentController, PaymentController),
FeedbackController: Object.assign(FeedbackController, FeedbackController),
GalleryController: Object.assign(GalleryController, GalleryController),
AnnouncementController: Object.assign(AnnouncementController, AnnouncementController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers