import WebhookController from './WebhookController'
const Controllers = {
    WebhookController: Object.assign(WebhookController, WebhookController),
}

export default Controllers