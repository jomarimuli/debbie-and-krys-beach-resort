import Laravel from './Laravel'
const Resend = {
    Laravel: Object.assign(Laravel, Laravel),
}

export default Resend