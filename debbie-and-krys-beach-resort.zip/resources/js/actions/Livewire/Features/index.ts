import SupportFileUploads from './SupportFileUploads'
const Features = {
    SupportFileUploads: Object.assign(SupportFileUploads, SupportFileUploads),
}

export default Features