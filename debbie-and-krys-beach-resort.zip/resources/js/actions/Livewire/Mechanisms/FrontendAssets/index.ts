import FrontendAssets from './FrontendAssets'
const FrontendAssets = {
    FrontendAssets: Object.assign(FrontendAssets, FrontendAssets),
}

export default FrontendAssets