import HandleRequests from './HandleRequests'
const HandleRequests = {
    HandleRequests: Object.assign(HandleRequests, HandleRequests),
}

export default HandleRequests