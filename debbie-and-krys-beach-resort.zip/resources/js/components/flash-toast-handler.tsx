import { useFlashToasts } from '@/hooks/use-flash-toasts';

export default function FlashToastHandler() {
    useFlashToasts();
    return null;
}
